const mongoose = require("mongoose");
const { type } = require("os");

const yeraGroupSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
        },
        createdBy:{
            type: mongoose.Schema.Types.ObjectId,
            ref: "Admin",
            required: true,
        },
        academicYear: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "AcademicYear",
            required: true,
        },
    },
    {
        timestamps: true,
    }
);
//model
const YearGroup = mongoose.model("YearGroup",yeraGroupSchema);
module.exports = YearGroup;  