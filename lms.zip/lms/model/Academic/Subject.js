const mongoose = require("mongoose");
const { type } = require("os");

const{ Schema } = mongoose;

const subjectSchema = new Schema(
    {
        name: {
            type: String,

        },
        description: {
            type: String,

        },
        teacher: {
            type: Schema.Types.ObjectId,
            ref: "Teacher",

        },
        academicTerm: {
            type: Schema.Types.ObjectId,
            ref: "AcademiTerm",
            required: true,

        },
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "Admin",
            required: true,

        },
        duration: {
            type: String,
            required: true,
            default: "3 months",

        },

    },
    {timestamps: true}

);
const Subject = mongoose.model("Subject",subjectSchema);
module.exports = Subject;   