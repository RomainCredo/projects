const mangoose = require("mongoose");

const{ Schema } = mongoose;
//exam schema
const examSchema = new Schema(
    {
        name:{
            type: String,
            required: true,

        },
        description:{
            type:String,
            required: true,

        },
        subject:{
            type:Schema.Types.ObjectId,
            ref:"Subject",
            required:true,

        },
        program:{
            type:Schema.Types.ObjectId,
            ref: "Program",
            required: true,
        },
        passMark: {
            type: Number,
            required: true,
            default:50,

        },
        totalMark:{
            type: Number,
            required: true,
            default: true,
        },
        academicTerm: {
            type: Schema.Types.ObjectId,
            ref:"AcademicTerm",
            required:true,
        },
        duration:{
            type:String,
            required:true,
            default: "30 minutes",

        },
        examDate: {
            type: Date,
            required: true,
        },
        examTime: {
            type:String,
            required:true,
        },
        examType: {
            type: String,
            required: true,
            default: "Quiz",

        },
        examStatus: {
            type: String,
            required: true,
            default: "Pending",
            enum: ["pending","live"],
        },
        questions: [
            {
                type:Schema.Types.ObjectId,
                ref:"Question",
            },
        ],
        classLevel:{
            type:Schema.Types.ObjectId,
            ref: "classLevel",
            required: true,
        },
        createdBy:{
            type: Schema.Types.ObjectId,
            ref:"AcademicTerm",
            required: true,
        },
        academicTerm:{
            type:Schema.Types.ObjectId,
            ref:"AcademicTerm",
            required:true,

        }, 
        academicYear:{
            type:Schema.Types.ObjectId,
            ref:"AcademicYear",
            required:true,
        },
    },
    { timestamps: true }
);
const Exam = mogoose.model("Exam",examSchema);
module.exports = Exam;