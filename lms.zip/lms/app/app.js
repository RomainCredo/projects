const express = require('express');
const morgan = require('morgan');

const app = express();

//Middlewares
app.use(morgan("dev"));

//Routes

//admin register
app.post("/api/v1/admins/register",(req,res)=>{

});

//admin login
app.post("/api/v1/admins/login",(req,res)=>{

});

//Get all admins
app.get("/api/v1/admins",(req,res)=>{

});

//Get single admin 
app.get("/api/v1/admins/:id",(req,res)=>{

});
//update admin 
app.put("/api/v1/admins/:id",(req,res)=>{

});
//delete admin 
app.delete("/api/v1/admins/:id",(req,res)=>{

});
//admin suspending teacher
app.put("/api/v1/admins/suspend/teacher/:id",(req,res)=>{

});
// admin unsuspending teacher
app.put('/api/v1/admins/unsuspend/teacher/:id',(req,res)=>{
});
// admin withdrawing teacher
app.put('/api/v1/admins/withdraw/teacher/:id',(req,res)=>{
});

// admin publish exam results teacher
app.put('/api/v1/admins/unpublish/exam/teacher/exam/:id',(req,res)=>{
});

// admin unpublish exam results teacher
app.put('/api/v1/admins/unpublish/exam/teacher/exam/:id',(req,res)=>{
    try{
        res.status(201).json({
            status: 'Success',
            data:'admin unpublish exam',

        });

    }
    catch(error){
        res.json({
            status:"failed",
            error: error.message,
        });
    }

}); 

module.exports = app;







